#' Search the Github API.
#' @param q Query string
#' @param ... Further arguments passed on to Github API call
#' @param ctx Authentication object
#' @export
