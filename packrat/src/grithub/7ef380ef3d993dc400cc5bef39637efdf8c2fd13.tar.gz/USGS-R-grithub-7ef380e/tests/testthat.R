library(testthat)
library(grithub)

test_check("grithub")
