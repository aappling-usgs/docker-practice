f <- function() {
  g()
}

g <- function() {
}
