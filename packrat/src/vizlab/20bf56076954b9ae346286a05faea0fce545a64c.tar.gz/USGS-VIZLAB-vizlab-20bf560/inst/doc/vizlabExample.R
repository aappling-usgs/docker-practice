## ----setup, include=FALSE------------------------------------------------
library(rmarkdown)

## ----eval=FALSE----------------------------------------------------------
#  install.packages('devtools')
#  devtools::install_github('USGS-VIZLAB/vizlab')

## ---- eval=FALSE---------------------------------------------------------
#  as.viz('cars_data')

